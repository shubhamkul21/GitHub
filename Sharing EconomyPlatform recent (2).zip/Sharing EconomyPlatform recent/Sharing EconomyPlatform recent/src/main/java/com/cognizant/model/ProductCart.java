package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class ProductCart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cartId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@OneToMany(mappedBy = "productCart",cascade = CascadeType.ALL)
	private List<ProductCartItems> productCartItems=new ArrayList<>();


	public ProductCart() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cartId
	 * @param customer
	 * @param productCartItems
	 * @param total
	 */
	public ProductCart(Integer cartId, Customer customer, List<ProductCartItems> productCartItems) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		this.productCartItems = productCartItems;
	}
	
	public void add(ProductCartItems productCartItem) {
		this.productCartItems.add(productCartItem);
	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<ProductCartItems> getProductCartItems() {
		return productCartItems;
	}

	public void setProductCartItems(List<ProductCartItems> productCartItems) {
		this.productCartItems = productCartItems;
	}



}

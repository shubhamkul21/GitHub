package com.cognizant.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
@GetMapping("/")
public String HomePage(Model model) {
	model.addAttribute("msg","Welcome to the Sharing Economy Platform");
	return "index";
}
}

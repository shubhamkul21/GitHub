package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ProductCategory;
import com.cognizant.model.ServiceObject;
import com.cognizant.model.ServiceCategory;
@Repository
public interface ServiceDao extends JpaRepository<ServiceObject, Integer> {
	
	@Query(value = "select * from service where service_category_id=?1",nativeQuery = true)
	List<ServiceObject> findByServiceCategoryName(String categoryName);

	ServiceObject findByServiceId(int serviceId);

	@Query(value = "select * from service where service_id=?1 and vendor_id=?2",nativeQuery = true)
	ServiceObject findByServiceIdAndVendorId(int serviceId, int vendorId);

	List<ServiceObject> findAllByVendorId(int vendorId);

	//Service findByServiceIdAndVendorUserId(int serviceId);

	

}

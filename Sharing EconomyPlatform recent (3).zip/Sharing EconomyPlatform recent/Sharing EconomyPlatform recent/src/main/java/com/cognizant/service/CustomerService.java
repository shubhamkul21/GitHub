package com.cognizant.service;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CustomerDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.model.Customer;

@Service
public class CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private ProductDao productDao;
	
	
		public boolean validateSecretAns(String customerUserId, String secretQ, String secretAns) {
			
			// TODO Auto-generated method stub
			boolean b=false;
			Customer customer=customerDao.findByCustomerUserIdAndSecretQAndSecretAns(customerUserId,secretQ,secretAns);
			if(customer!=null)
			{
			System.out.println(customer.getContactNumber());
			b=true;
			}
			
			return b;	
			
		}
		public void resetPassword(String customerUserId, String password) {
			// TODO Auto-generated method stub
			Customer customer=customerDao.findByCustomerUserId(customerUserId);
			customer.setPassword(password);
			customerDao.save(customer);
			System.out.println(customer.getPassword());
		}
		public Customer findByCustomerUserId(String customerUserId) {
			// TODO Auto-generated method stub
			return customerDao.findByCustomerUserId( customerUserId);
			
		}
		public void save(@Valid Customer customer) {
			customerDao.save(customer);
			
		}
		public Customer findByCustomerUserIdAndPassword(String username, String password) {
			return customerDao.findByCustomerUserIdAndPassword(username,password);
		}
		
		
	
}

package com.cognizant.service;

import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.model.ProductCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ProductCategoryService{
    @Autowired
	private ProductCategoryDao productCategoryDao;
    
	

    public List<String> getProductCategories() {
        List<String> categoryNames=new ArrayList<>();
        List<ProductCategory> categories=productCategoryDao.findCategories();
        for(ProductCategory category:categories){
            System.out.println(category.getProductCategoryName()+"\t"+category.getProductCategoryId());
            categoryNames.add(category.getProductCategoryName());
        }
        return categoryNames;
    }

	public List<String> getAllProductCategories() {
        List<String> categoryName=new ArrayList<>();
        
        List<ProductCategory> allCategories=productCategoryDao.findAllCategories();
        for(ProductCategory category:allCategories) {
        	categoryName.add(category.getProductCategoryName());
        }
		return categoryName;
	}

	public List<ProductCategory> findAll() {
		return productCategoryDao.findAll();
	}

	public void save(ProductCategory productCategory) {
		
		productCategoryDao.save(productCategory);
		
		
	}

	public ProductCategory findProductCategoryByProductCategoryName(String categoryName) {
		return productCategoryDao.findProductCategoryByProductCategoryName(categoryName);
	}

	public ProductCategory findByProductCategoryName(String categoryName) {
		return productCategoryDao.findByProductCategoryName(categoryName);
	}

	public ProductCategory findAllByProductCategoryId(int productCategoryId) {
		// TODO Auto-generated method stub
		return productCategoryDao.findAllByProductCategoryId(productCategoryId);
	}

	public List<ProductCategory> findAllByProductCategoryName(String categoryName) {
		return productCategoryDao.findAllByProductCategoryName(categoryName);
	}

	
	
}

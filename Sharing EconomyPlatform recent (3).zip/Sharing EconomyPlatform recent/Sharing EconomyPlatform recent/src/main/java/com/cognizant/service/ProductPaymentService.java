package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ProductPaymentDao;
import com.cognizant.model.ProductPayment;

@Service
public class ProductPaymentService {
    @Autowired
	private ProductPaymentDao productPaymentDao;
	
    public void save(ProductPayment productPayment) {
		productPaymentDao.save(productPayment);
		
	}

}

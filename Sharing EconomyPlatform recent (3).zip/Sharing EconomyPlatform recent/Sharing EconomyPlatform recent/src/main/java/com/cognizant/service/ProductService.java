package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ProductDao;
import com.cognizant.model.Product;
@Service
public class ProductService {
    @Autowired
	private ProductDao productDao;
	
	public void save(Product product) {
		productDao.save(product);		
	}

	public Product findByProductId(int productId) {
		return productDao.findByProductId(productId);
	}

	public void delete(Product product) {
		productDao.delete(product);	
		
	}

}

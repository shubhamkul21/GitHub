package com.cognizant.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.AdminDao;
import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.model.Admin;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.ServiceCategory;
import com.cognizant.model.Vendor;

@Controller
public class AdminController {
	@Autowired
	private AdminDao adminDao;
	@Autowired
	private ProductCategoryDao productCategoryDao;
	@Autowired
	private ServiceCategoryDao serviceCategoryDao;
	
	@GetMapping("/adminLogin")
	public String customerLogin() {
		
		return "adminLogin";
	}
	@PostMapping("/adminAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model) {
	    Admin correct= adminDao.findByUsernameAndPassword(username, password);
		
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	System.out.println(session.getAttribute("username"));
	    	return "admin";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "adminLogin";
	     }		
	}
	
	@GetMapping("/adminLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	
	// display add product category form
		@GetMapping("/viewAdminAddProductCategory")
		public String viewAdminAddProductCategory(HttpServletRequest request) {
			request.setAttribute("mode", "MODE_ADDPRODUCTCATEGORY");
			return "admin";

		}

		// display add service category form
		@GetMapping("/viewAdminAddServiceCategory")
		public String viewAdminAddServiceCategory(HttpServletRequest request) {
			request.setAttribute("mode", "MODE_ADDSERVICECATEGORY");
			return "admin";

		}
		// display list of product category added by vendor
		@GetMapping("/viewAdminProductCategorys")
		public String viewAdminProductCategorys(HttpServletRequest request,HttpSession session,Model model) {
			List<ProductCategory> productCategories=productCategoryDao.findAll();
			model.addAttribute("productCategories", productCategories);
			request.setAttribute("mode", "MODE_VIEWPRODUCTCATEGORYS");
			return "admin";

		}

		// display list of service category added by vendor
		@GetMapping("/viewAdminServiceCategorys")
		public String viewAdminServiceCategorys(HttpServletRequest request,HttpSession session,Model model) {
			
			List<ServiceCategory> serviceCategories=serviceCategoryDao.findAll();
			model.addAttribute("serviceCategories", serviceCategories);
			request.setAttribute("mode", "MODE_VIEWSERVICECATEGORYS");		
			return "admin";

		}
		
		// add product category in db
		@RequestMapping("/addAdminProductCategory")
		public String addAdminProductCategory(@ModelAttribute("productCategory") ProductCategory productCategory, ModelMap map,
				HttpSession session) {
										
			productCategoryDao.save(productCategory);
			return "admin";

		}

		// add service category in db
		@RequestMapping("/addAdminServiceCategory")
		public String addAdminServiceCategory(@ModelAttribute("serviceCategory") ServiceCategory serviceCategory, ModelMap map,
				HttpSession session) {
			
			serviceCategoryDao.save(serviceCategory);
			
			return "admin";

		}

	
	
	
	
	
	

}

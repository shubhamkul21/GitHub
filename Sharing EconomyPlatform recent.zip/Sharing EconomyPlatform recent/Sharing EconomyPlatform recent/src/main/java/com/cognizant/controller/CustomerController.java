package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cognizant.dao.CustomerDao;
import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.dao.ServiceDao;
import com.cognizant.model.Customer;
import com.cognizant.model.Product;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.Service;
import com.cognizant.model.ServiceCategory;
import com.cognizant.model.Vendor;
import com.cognizant.service.CustomerService;
import com.cognizant.service.ProductCategoryService;
import com.cognizant.service.ServiceCategoryService;

@Controller
public class CustomerController {
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private ProductDao productDao;
	@Autowired
	private ServiceDao serviceDao;
	@Autowired
	private ProductCategoryDao productCategoryDao;
	@Autowired
	private ServiceCategoryDao serviceCategoryDao;
	@Autowired
	private ServiceCategoryService serviceCategoryService;

	@Autowired
	private ProductCategoryService productCategoryService;

	
	
	// displays registration form
	@GetMapping("/customer")
	public String viewCustomerRegister(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer",customer);
		return "customerRegister";
	}
	
	// validation and registration
	@PostMapping("/customerRegister")
	public String addVendor(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "customerRegister";
		}
		
		customerDao.save(customer);
		
		return "customerRegisterSuccess";		
	}
	
	// display login form
	@GetMapping("/customerLogin")
	public String customerLogin() {
		
		return "customerLogin";
	}
	
	// login
	@PostMapping("/customerAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model,HttpServletRequest request) {
	     Customer correct=customerDao.findByCustomerUserIdAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	//System.out.println(session.getAttribute("username"));
	    	request.setAttribute("mode", "MODE_HOME");
	    	return "customer";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "customerLogin";
	     }
		
	}
	
	// logout
	@GetMapping("/customerLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	
	// gets list of product category to display in drop-down from db
	@GetMapping("/allProductCategories")
	@ResponseBody
	public List<String> getAllProductCategories(HttpSession session) {
		List<String> allProductCategories = productCategoryService.getAllProductCategories();
		return allProductCategories;
	}

	// gets list of service category to display in drop-down from db
	@GetMapping("/allServiceCategories")
	@ResponseBody
	public List<String> getAllServiceCategories(HttpSession session) {
		List<String> allServiceCategories = serviceCategoryService.getAllServiceCategories();
		return allServiceCategories;
	}
	
	//displays list of all product based on category selected
	@GetMapping("/showAllProduct")
	public String showAllProduct(@RequestParam("categoryName") String categoryName,Model model,HttpServletRequest request){
	List<ProductCategory> productCategorys=productCategoryDao.findAllByProductCategoryName(categoryName);
	//System.out.println(productCategory);
	List<Product> products=new ArrayList<>();
	productCategorys.stream().forEach(productCategory->{
		
		productCategory.getProducts().stream().forEach(product->{
			
			products.add(product);
		});
		
	});
	
	model.addAttribute("products",products);
	request.setAttribute("mode", "MODE_SHOWALLPRODUCTS");
	return "customer";
	
	}
	
	//displays list of all services based on category selected
	@GetMapping("/showAllService")
	public String showAllService(@RequestParam("categoryName") String categoryName,Model model,HttpServletRequest request){
		
	
	List<ServiceCategory> serviceCategorys=serviceCategoryDao.findAllByServiceCategoryName(categoryName);
	List<Service> services=new ArrayList<>();
	serviceCategorys.stream().forEach(serviceCategory->{
		serviceCategory.getServices().stream().forEach(service->{
			
			services.add(service);
			
		});;
	});
	model.addAttribute("services",services);
	request.setAttribute("mode", "MODE_SHOWALLSERVICES");
	return "customer";
	}
	
	@GetMapping("/viewProductDetails")
	public String viewProductDetails(@RequestParam("productId") int productId,Model model,HttpServletRequest request) {
		Product product=productDao.findByProductId(productId);
		System.out.println(product);
		Vendor vendor=product.getVendor();
		model.addAttribute("productDetails",product);
		model.addAttribute("vendorDetails",vendor);
		request.setAttribute("mode", "MODE_VIEWPRODUCTDETAILS");
		return "customer";
	}
	
		
	
	
	//display the secret questions
	@ModelAttribute("secretQ")
	public List<String> populateQ(){
		List<String> secretQ=new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;
	}


}

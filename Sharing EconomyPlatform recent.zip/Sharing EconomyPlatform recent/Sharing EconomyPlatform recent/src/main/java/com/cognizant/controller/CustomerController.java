package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cognizant.dao.CustomerDao;
import com.cognizant.dao.ProductCartDao;
import com.cognizant.dao.ProductCartItemsDao;
import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.dao.ProductPaymentDao;
import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.dao.ServiceDao;
import com.cognizant.dao.ServicePaymentDao;
import com.cognizant.model.Customer;
import com.cognizant.model.ServicePayment;
import com.cognizant.model.Product;
import com.cognizant.model.ProductCart;
import com.cognizant.model.ProductCartItems;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.ProductPayment;
import com.cognizant.model.Service;
import com.cognizant.model.ServiceCategory;
import com.cognizant.model.Vendor;
import com.cognizant.service.CustomerService;
import com.cognizant.service.CustomerServiceImpl;
import com.cognizant.service.ProductCategoryService;
import com.cognizant.service.ServiceCategoryService;

@Controller
public class CustomerController {
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private ProductDao productDao;
	@Autowired
	private ServiceDao serviceDao;

	@Autowired
	private CustomerServiceImpl customerServiceImpl;
	@Autowired
	private ProductCategoryDao productCategoryDao;
	@Autowired
	private ServiceCategoryDao serviceCategoryDao;
	@Autowired
	private ProductCartItemsDao productCartItemsDao;
	@Autowired
	private ServiceCategoryService serviceCategoryService;
	@Autowired
	private ProductCategoryService productCategoryService;
	@Autowired
	private ProductCartDao productCartDao;
	@Autowired
	private ProductPaymentDao productPaymentDao;
	@Autowired
	private ServicePaymentDao servicePaymentDao;
	
	
	// displays registration form
	@GetMapping("/customer")
	public String viewCustomerRegister(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer",customer);
		return "customerRegister";
	}
	
	// validation and registration
	@PostMapping("/customerRegister")
	public String addVendor(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "customerRegister";
		}
		
		ProductCart productCart=new ProductCart();
		customer.setProductCart(productCart);
		productCart.setCustomer(customer);
		customerDao.save(customer);
			
		return "customerRegisterSuccess";		
	}
	
	// display login form
	@GetMapping("/customerLogin")
	public String customerLogin() {
		
		return "customerLogin";
	}
	
	// login
	@PostMapping("/customerAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model,HttpServletRequest request) {
	     Customer correct=customerDao.findByCustomerUserIdAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	//System.out.println(session.getAttribute("username"));
	    	request.setAttribute("mode", "MODE_HOME");
	    	return "customer";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "customerLogin";
	     }
		
	}
	
	// logout
	@GetMapping("/customerLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	
	 @GetMapping("customerforgotpassword")
	 public String forgotPassword()
	 {
		 return "customerForgotPassword";
	 }
	 @PostMapping("customersecretans")
	 public String secretansAuthgentication(@RequestParam("customerUserId") String customerUserId,@RequestParam("secretQ") String secretQ,
			 @RequestParam("secretAns") String secretAns,Model model,HttpSession session) 
	 {
		 boolean isValid=customerServiceImpl.validateSecretAns(customerUserId,secretQ,secretAns);
		 if(isValid) {
			
			 session.setAttribute("customerUserId", customerUserId);
			 Customer customer =customerServiceImpl.findByCustomerUserId((String)session.getAttribute("customerUserId"));
			 model.addAttribute("customername",customer.getFirstName());
			 
			 return "customerPasswordReset";
			 }
		 
		 else {
			 model.addAttribute("msg", "Sorry! Incorrect Answer");
			 return "customerForgotPassword";
		 }
	 }
	 @PostMapping("customerresetpassword")
	 public String resetPassword(@RequestParam("password") String password,HttpSession session) {
		 String customerUserId=(String)session.getAttribute("customerUserId");
		 customerServiceImpl.resetPassword(customerUserId,password);
		 return "customerLogin";
	 }
	
	
	
	
	
	// gets list of product category to display in drop-down from db
	@GetMapping("/allProductCategories")
	@ResponseBody
	public List<String> getAllProductCategories(HttpSession session) {
		List<String> allProductCategories = productCategoryService.getAllProductCategories();
		return allProductCategories;
	}

	// gets list of service category to display in drop-down from db
	@GetMapping("/allServiceCategories")
	@ResponseBody
	public List<String> getAllServiceCategories(HttpSession session) {
		List<String> allServiceCategories = serviceCategoryService.getAllServiceCategories();
		return allServiceCategories;
	}
	
	//displays list of all product based on category selected
	@GetMapping("/showAllProduct")
	public String showAllProduct(@RequestParam("categoryName") String categoryName,Model model,HttpServletRequest request,HttpSession session){
	List<ProductCategory> productCategorys=productCategoryDao.findAllByProductCategoryName(categoryName);
	//System.out.println(productCategory);
	session.setAttribute("categoryName", categoryName);
	List<Product> products=new ArrayList<>();
	productCategorys.stream().forEach(productCategory->{
		
		productCategory.getProducts().stream().forEach(product->{
			
			products.add(product);
		});
		
	});
	
	model.addAttribute("products",products);
	request.setAttribute("mode", "MODE_SHOWALLPRODUCTS");
	return "customer";
	
	}
	
	//displays list of all services based on category selected
	@GetMapping("/showAllService")
	public String showAllService(@RequestParam("categoryName") String categoryName,Model model,HttpServletRequest request,HttpSession session){
		
	session.setAttribute("categoryName", categoryName);
	List<ServiceCategory> serviceCategorys=serviceCategoryDao.findAllByServiceCategoryName(categoryName);
	List<Service> services=new ArrayList<>();
	serviceCategorys.stream().forEach(serviceCategory->{
		serviceCategory.getServices().stream().forEach(service->{
			
			services.add(service);
			
		});;
	});

	model.addAttribute("services",services);
	request.setAttribute("mode", "MODE_SHOWALLSERVICES");
	return "customer";
	}
	
	@GetMapping("/viewProductDetails")
	public String viewProductDetails(@RequestParam("productId") int productId,Model model,HttpServletRequest request) {
		Product product=productDao.findByProductId(productId);
		System.out.println(product);
		Vendor vendor=product.getVendor();
		model.addAttribute("productDetails",product);
		model.addAttribute("vendorDetails",vendor);
		request.setAttribute("mode", "MODE_VIEWPRODUCTDETAILS");
		return "customer";
	}
	
	@GetMapping("/addProductToCart")
	public String addProductToCart(@RequestParam("productId") int productId,HttpSession session) {
		Product product=productDao.findByProductId(productId);
		
		String custonerUserId=(String) session.getAttribute("username");
		Customer customer=customerDao.findByCustomerUserId(custonerUserId);
		System.out.println(customer.getCity());
		ProductCart productCart=customer.getProductCart();
		
		if(productCart!=null) {
		List<ProductCartItems> productCartItems=productCart.getProductCartItems();
		
		for(int i=0;i<productCartItems.size();i++) {
			ProductCartItems productCartItems2 = productCartItems.get(i);
			if (product.getProductId()==productCartItems2.getProduct().getProductId()) {
				productCartItems2.setQuantity(productCartItems2.getQuantity() + 1);
				productCartItems2.setPrice(productCartItems2.getQuantity() * productCartItems2.getProduct().getPrice());
				productCartItems2.setProduct(product);
				productCartItems2.setProductCart(customer.getProductCart());
				productCartItems2.setCustomer(customer);
				productCartItemsDao.save(productCartItems2);
				return "customer";
			}
		}
		}
		ProductCartItems productCartItems1 = new ProductCartItems();
		
		productCartItems1.setQuantity(1);
		productCartItems1.setProduct(product);
		productCartItems1.setPrice(product.getPrice() * 1);
		productCartItems1.setProductCart(customer.getProductCart());
		productCartItems1.setCustomer(customer);
		
		productCartItemsDao.save(productCartItems1);
				
		return "customer";
	}
	
	@GetMapping("/viewProductCart")
	public String viewProductCart(HttpServletRequest request,Model model,HttpSession session) {
		String custonerUserId=(String) session.getAttribute("username");
		Customer customer=customerDao.findByCustomerUserId(custonerUserId);
		int customerId=customer.getId();
		List<ProductCartItems> productCartItems=productCartItemsDao.findAllByCustomerId(customerId);
		double total=0.0;
		for(ProductCartItems pci:productCartItems) {
			total=total+(pci.getPrice());
		}
		model.addAttribute("total", total);
		model.addAttribute("productCartItems", productCartItems);
		request.setAttribute("mode", "MODE_VIEWPRODUCTCART");
		return "customer";
		
	}
	
	
	@GetMapping("/servicePayment")
	public String servicePayment(@RequestParam("serviceId") int serviceId,HttpServletRequest request,HttpSession session) {
		
		session.setAttribute("serviceId", serviceId);
		request.setAttribute("mode", "MODE_SERVICEPAYMENT");
		return "customer";
	}	
	

	@GetMapping("/viewCardPayment")
	public String viewCardPayment(HttpServletRequest request) {
		
		request.setAttribute("mode", "MODE_VIEWCARDPAYMENT");
		return "customer";
		
	}
	
	@GetMapping("/viewUpiPayment")
	public String viewUpiPayment(HttpServletRequest request) {
		
		request.setAttribute("mode", "MODE_VIEWUPIPAYMENT");
		return "customer";
		
	}
	@GetMapping("/viewProductCardPayment")
	public String viewProductCardPayment(HttpServletRequest request) {
		
		request.setAttribute("mode", "MODE_VIEWPRODUCTCARDPAYMENT");
		return "customer";
		
	}
	
	@GetMapping("/viewProductUpiPayment")
	public String viewProductUpiPayment(HttpServletRequest request) {
		
		request.setAttribute("mode", "MODE_VIEWPRODUCTUPIPAYMENT");
		return "customer";
		
	}
	
	//payment from card and upi
	@PostMapping("/servicePayment")
	public String servicePayment(@RequestParam("number") String number,HttpSession session) {
		String customerUserId = (String) session.getAttribute("username");
		Customer customer = customerDao.findByCustomerUserId(customerUserId);
		int serviceId= (int) session.getAttribute("serviceId");
		Service service=serviceDao.findByServiceId(serviceId);
		Vendor vendor=service.getVendor();
		
		ServicePayment servicePayment1=new ServicePayment();
		servicePayment1.setNumber(number);
		servicePayment1.setStatus("pending");
		servicePayment1.setCustomer(customer);
		servicePayment1.setService(service);
		servicePayment1.setVendor(vendor);
		servicePaymentDao.save(servicePayment1);
		return "customer";
		
	}
	
	@PostMapping("/productPayment")
	public String productPayment(@RequestParam("number") String number,Model model,HttpServletRequest request,HttpSession session) {
		String customerUserId = (String) session.getAttribute("username");
		Customer customer = customerDao.findByCustomerUserId(customerUserId);
				
		ProductPayment productPayment=new ProductPayment();
		productPayment.setNumber(number);
		productPayment.setStatus("successful");
		productPayment.setCustomer(customer);
		
		productPaymentDao.save(productPayment);
		
		int customerId=customer.getId();
		List<ProductCartItems> productCartItems=productCartItemsDao.findAllByCustomerId(customerId);
		double total=0.0;
		for(ProductCartItems pci:productCartItems) {
			total=total+(pci.getPrice());
		}
		model.addAttribute("customer", customer);
		model.addAttribute("total", total);
		model.addAttribute("productCartItems", productCartItems);
		request.setAttribute("mode", "MODE_VIEWPRODUCTSBILL");
		return "customer";
		
	}
	
	@GetMapping("/getPendingServices")
	public String getPendingServices(HttpServletRequest request,Model model,HttpSession session) {
		String customerUserId = (String) session.getAttribute("username");
		Customer customer = customerDao.findByCustomerUserId(customerUserId);
		int customerId=customer.getId();
		System.out.println(customerId);
		List<ServicePayment> servicePayments=servicePaymentDao.findAllByServiceIdAndCustomerId("pending", customerId);
		for(ServicePayment s:servicePayments) {
			System.out.println(s.getStatus());
			System.out.println(s.getNumber());
			
		}
		model.addAttribute("servicePayments", servicePayments);
		request.setAttribute("mode", "MODE_PENDINGSERVICES");
		return "customer";
	}
	
	@GetMapping("/getClosedServices")
	public String getClosedServices(HttpServletRequest request,Model model,HttpSession session) {
		String customerUserId = (String) session.getAttribute("username");
		Customer customer = customerDao.findByCustomerUserId(customerUserId);
		int customerId=customer.getId();
		
		List<ServicePayment> servicePayments=servicePaymentDao.findAllByServiceIdAndCustomerId("closed",customerId);
		model.addAttribute("servicePayments", servicePayments);
		request.setAttribute("mode", "MODE_CLOSEDSERVICES");
		return "customer";
	}
	
	
	@GetMapping("/filterLessThan")
	public String filterLessThan(HttpServletRequest request,Model model,HttpSession session) {
		String categoryName=(String) session.getAttribute("categoryName");
		List<ProductCategory> productCategorys=productCategoryDao.findAllByProductCategoryName(categoryName);
		//System.out.println(productCategory);
		List<Product> products=new ArrayList<>();
		productCategorys.stream().forEach(productCategory->{
			
			productCategory.getProducts().stream().forEach(product->{
				if(product.getPrice()<1000) {
				products.add(product);
				}
			});
			
		});
		
		model.addAttribute("products",products);
		request.setAttribute("mode", "MODE_SHOWALLPRODUCTS");
		return "customer";
		
		
	}

	@GetMapping("/filterGreaterThan")
	public String filterGreaterThan(HttpServletRequest request,Model model,HttpSession session) {
		String categoryName=(String) session.getAttribute("categoryName");
		List<ProductCategory> productCategorys=productCategoryDao.findAllByProductCategoryName(categoryName);
		//System.out.println(productCategory);
		List<Product> products=new ArrayList<>();
		productCategorys.stream().forEach(productCategory->{
			
			productCategory.getProducts().stream().forEach(product->{
				if(product.getPrice()>1000) {
				products.add(product);
				}
			});
			
		});
		
		model.addAttribute("products",products);
		request.setAttribute("mode", "MODE_SHOWALLPRODUCTS");
		return "customer";
		
		
	}
	
	@GetMapping("/showAllService/searchByAddress")
	public String searchByAddress(@RequestParam("address") String address,Model model,HttpServletRequest request,HttpSession session){
    String categoryName=(String) session.getAttribute("categoryName");
	session.setAttribute("categoryName", categoryName);
	List<ServiceCategory> serviceCategorys=serviceCategoryDao.findAllByServiceCategoryName(categoryName);
	List<Service> services=new ArrayList<>();
	serviceCategorys.stream().forEach(serviceCategory->{
		serviceCategory.getServices().stream().forEach(service->{
			if(service.getVendor().getAddress().equalsIgnoreCase(address)) {
			services.add(service);
			}
			
		});
	});
	model.addAttribute("services",services);
	request.setAttribute("mode", "MODE_SHOWALLSERVICES");
	return "customer";
	}
	
	//display the secret questions
	@ModelAttribute("secretQ")
	public List<String> populateQ(){
		List<String> secretQ=new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;
	}


}

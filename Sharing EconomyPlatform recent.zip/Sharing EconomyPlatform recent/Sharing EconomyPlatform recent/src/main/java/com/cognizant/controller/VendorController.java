package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.cognizant.service.ProductCategoryService;
import com.cognizant.service.ProductCategoryServiceImpl;
import com.cognizant.service.ServiceCategoryService;
import com.cognizant.service.VendorServiceImpl;

import org.apache.coyote.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestDataValueProcessor;

import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.dao.ServiceDao;
import com.cognizant.dao.VendorDao;
import com.cognizant.model.Product;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.Service;
import com.cognizant.model.ServiceCategory;
import com.cognizant.model.Vendor;

@Controller
public class VendorController {
	@Autowired
	private VendorDao vendorDao;
	@Autowired
	private ProductDao productDao;
	@Autowired
	private ServiceDao serviceDao;
	@Autowired
	private VendorServiceImpl vendorServiceImpl;

	@Autowired
	private ProductCategoryDao productCategoryDao;
	@Autowired
	private ServiceCategoryDao serviceCategoryDao;
	@Autowired
	private ProductCategoryService productCategoryService;
	@Autowired
	private ServiceCategoryService serviceCategoryService;

	// displays registration form
	@GetMapping("/vendor")
	public String viewVendorRegister(Model model) {
		Vendor vendor = new Vendor();
		model.addAttribute("vendor", vendor);
		return "vendorRegister";
	}

	// validation and registration
	@PostMapping("/vendorRegister")
	public String addVendor(@Valid @ModelAttribute("vendor") Vendor vendor, BindingResult result, ModelMap map) {
		if (result.hasErrors()) {
			return "vendorRegister";
		}

		vendorDao.save(vendor);
		return "vendorRegisterSuccess";
	}

	// display login form
	@GetMapping("/vendorLogin")
	public String vendorLogin() {

		return "vendorLogin";
	}

	// login
	@PostMapping("/vendorAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password, HttpSession session, Model model, HttpServletRequest request) {
		Vendor vendor = vendorDao.findByVendorUserIdAndPassword(username, password);
		if (!(ObjectUtils.isEmpty(vendor))) {
			session.setAttribute("username", username);
			//System.out.println(session.getAttribute("username"));
			return "vendorDetails";
		} else {
			System.out.println("false");
			model.addAttribute("msg", "Invalid Login Credentials");
			return "vendorLogin";
		}
	}

	// logout
	@GetMapping("/vendorLogout")
	public String logout(HttpSession session) {
		//System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		//System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	
	
	 @GetMapping("/forgotpassword")
	 public String forgotPassword()
	 {
		 return "vendorForgotPassword";
	 }
	 @PostMapping("/vendorsecretans")
	 public String secretansAuthgentication(@RequestParam("vendorUserId") String vendorUserId,@RequestParam("secretQ") String secretQ,
			 @RequestParam("secretAns") String secretAns,Model model,HttpSession session) 
	 {
		 boolean isValid=vendorServiceImpl.validateSecretAns(vendorUserId,secretQ,secretAns);
		 if(isValid) {
			
			 session.setAttribute("vendorUserId", vendorUserId);
			 Vendor vendor =vendorDao.findByVendorUserId((String)session.getAttribute("vendorUserId"));
			 model.addAttribute("vendorname",vendor.getFirstName());
			 
			 return "vendorPasswordReset";
			 }
		 
		 else {
			 model.addAttribute("msg", "Sorry! Incorrect Answer");
			 return "vendorForgotPassword";
		 }
	 }
	 @PostMapping("/vendorresetpassword")
	 public String resetPassword(@RequestParam("password") String password,HttpSession session) {
		 String vendorUserId=(String)session.getAttribute("vendorUserId");
		 vendorServiceImpl.resetPassword(vendorUserId,password);
		 return "vendorLogin";
	 }

	
	
	
	@GetMapping("/vendorupdate")
	public String vendorUpdate(ModelMap map,HttpSession session,HttpServletRequest request) {
	   
	  Vendor vendor =vendorDao.findByVendorUserId((String)session.getAttribute("username"));
	     map.addAttribute("vendor", vendor);
	     map.addAttribute("vendorname",vendor.getFirstName());
	     request.setAttribute("mode", "MODE_UPDATEPROFILE");
		return "vendorDetails";
	
	}
	@PostMapping("/updateauthentication")

	public  String vendorUpdateAuthenticatio(@ModelAttribute("vendor") Vendor vendor,Model model,HttpSession session,BindingResult result,
			@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,@RequestParam("gender") String gender,
			@RequestParam("city") String city,@RequestParam("state") String state,@RequestParam("zip") String zip,
			@RequestParam("address") String address,@RequestParam("contactNumber") String contactNumber,@RequestParam("email") String email)
		 {
		 
			String currentSession=(String) session.getAttribute("username");
			vendorServiceImpl.update(currentSession, firstName, lastName, gender, contactNumber, address, city, state, zip, email);
		   		    model.addAttribute("msg", "Updated Successfully");
			 return "vendorDetails";
		
		
	}

	// gets list of product category to display in drop-down from db
	@GetMapping("/productCategories")
	@ResponseBody
	public List<String> getProductCategories(HttpSession session) {
		
		List<String> productCategories = productCategoryService.getProductCategories();
		//System.out.println(productCategories);
		return productCategories;
	}

	// gets list of service category to display in drop-down from db
	@GetMapping("/serviceCategories")
	@ResponseBody
	public List<String> getServiceCategories(HttpSession session) {
		
		List<String> serviceCategories = serviceCategoryService.getServiceCategories();
		return serviceCategories;
	}

	// display add product category form
	@GetMapping("/viewAddproduct")
	public String showAddProduct(@RequestParam("categoryName") String categoryName, Model model,
			HttpServletRequest request, HttpSession session) {
		ProductCategory productCategory = productCategoryDao.findProductCategoryByProductCategoryName(categoryName);
		//System.out.println(productCategory);
		
		request.setAttribute("categoryName", categoryName);
		session.setAttribute("productCategory", categoryName);
		request.setAttribute("mode", "MODE_VIEWADDPRODUCT");
		//System.out.println(categoryName);

		return "vendorDetails";
	}

	// display add service category form
	@GetMapping("/viewAddservice")
	public String showAddService(@RequestParam("categoryName") String categoryName, Model model,
			HttpServletRequest request, HttpSession session) {
		ServiceCategory serviceCategory = serviceCategoryDao.findServiceCategoryByServiceCategoryName(categoryName);
		model.addAttribute("category", serviceCategory);
		session.setAttribute("serviceCategory", categoryName);
		request.setAttribute("mode", "MODE_VIEWADDSERVICE");
		

		return "vendorDetails";
	}

	// adds the product in db
	@RequestMapping("/viewAddproduct/addProduct")
	public String addProduct(@ModelAttribute("product") Product product, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		//System.out.println(vendor.getId());
		// int vendorId=(int) session.getAttribute("vendorId");
		// request.setAttribute("vendorId", vendorId);
		String categoryName = (String) session.getAttribute("productCategory");
		ProductCategory productCategory= productCategoryDao.findByProductCategoryName(categoryName);
		product.setVendor(vendor);
		productCategory.setVendor(vendor);
		product.setProductCategory(productCategory);
		productDao.save(product);
		
		return "vendorDetails";

	}

	// adds service in db
	@RequestMapping("/viewAddservice/addService")
	public String addService(@ModelAttribute("service") Service service, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		String categoryName = (String) session.getAttribute("serviceCategory");
		ServiceCategory serviceCategory = serviceCategoryDao.findByServiceCategoryName(categoryName);
		service.setVendor(vendor);
		service.setServiceCategory(serviceCategory);
		serviceDao.save(service);		
		
		return "vendorDetails";

	}

	// display add product category form
	@GetMapping("/viewAddProductCategory")
	public String viewAddProductCategory(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_ADDPRODUCTCATEGORY");
		return "vendorDetails";

	}

	// display add service category form
	@GetMapping("/viewAddServiceCategory")
	public String viewAddServiceCategory(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_ADDSERVICECATEGORY");
		return "vendorDetails";

	}

	// add product category in db
	@RequestMapping("/addProductCategory")
	public String addProductCategory(@ModelAttribute("productCategory") ProductCategory productCategory, ModelMap map,
			HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		productCategory.setVendor(vendor);
		// session.setAttribute("vendorId", vendor.getId());
				
		productCategoryDao.save(productCategory);
		return "vendorDetails";

	}

	// add service category in db
	@RequestMapping("/addServiceCategory")
	public String addServiceCategory(@ModelAttribute("serviceCategory") ServiceCategory serviceCategory, ModelMap map,
			HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		serviceCategory.setVendor(vendor);
		// vendor.add(serviceCategory);
		serviceCategoryDao.save(serviceCategory);
		
		return "vendorDetails";

	}

	// display list of product added by vendor
	@GetMapping("/viewProducts")
	public String viewProducts(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		List<Product> products=vendor.getProduct();	
		model.addAttribute("products",products);
		request.setAttribute("mode", "MODE_VIEWPRODUCTS");
		return "vendorDetails";

	}

	// display list of service added by vendor
	@GetMapping("/viewServices")
	public String viewServices(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		List<Service> services=vendor.getService();
		model.addAttribute("services", services);
		request.setAttribute("mode", "MODE_VIEWSERVICES");
		return "vendorDetails";

	}

	// display list of product category added by vendor
	@GetMapping("/viewProductCategorys")
	public String viewProductCategorys(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		List<ProductCategory> productCategories=vendor.getProductCategory();
		model.addAttribute("productCategories", productCategories);
		request.setAttribute("mode", "MODE_VIEWPRODUCTCATEGORYS");
		return "vendorDetails";

	}

	// display list of service category added by vendor
	@GetMapping("/viewServiceCategorys")
	public String viewServiceCategorys(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		List<ServiceCategory> serviceCategories=vendor.getServiceCategory();
		model.addAttribute("serviceCategories", serviceCategories);
		request.setAttribute("mode", "MODE_VIEWSERVICECATEGORYS");		
		return "vendorDetails";

	}
	
	//display edit product form
	@GetMapping("/viewEditProduct")
	public String viewEditProduct(@RequestParam("productId") int productId,Model model,HttpServletRequest request,HttpSession session) {
		Product product=productDao.findByProductId(productId);
		//ProductCategory productCategory=product.getProductCategory();
		session.setAttribute("productId", productId);
		model.addAttribute("product",product);
		session.setAttribute("productId",productId);
		request.setAttribute("mode", "MODE_VIEWEDITPRODUCT");
		return "vendorDetails";
		
	}
	
	//display edit service form
	@GetMapping("/viewEditService")
	public String viewEditService(@RequestParam("serviceId") int serviceId,Model model,HttpServletRequest request,HttpSession session) {
		Service service=serviceDao.findByServiceId(serviceId);
		session.setAttribute("serviceId", serviceId);
		model.addAttribute("service",service);
		session.setAttribute("serviceId", serviceId);
		request.setAttribute("mode", "MODE_VIEWEDITSERVICE");
		return "vendorDetails";
		
	}
	
	
	@PostMapping("/viewEditProduct/editProduct")
	public String editProduct(@ModelAttribute("product") Product product, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		
		int productId=(int) session.getAttribute("productId");
		Product product2=productDao.findByProductId(productId);
		product2.setPrice(product.getPrice());
		product2.setProductName(product.getProductName());
		product2.setStatus(product.getStatus());
		product2.setVendor(vendor);
		productDao.save(product2);
		
		
		return "redirect:/viewProducts";

	}
	
	//edits the services
	@PostMapping("/viewEditService/editService")
	public String editService(@ModelAttribute("service") Service service, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		int serviceId=(int) session.getAttribute("serviceId");
		Service service2=serviceDao.findByServiceId(serviceId);
		service2.setPrice(service.getPrice());
		service2.setServiceName(service.getServiceName());
		service2.setStatus(service.getStatus());
		service2.setTimeings(service.getTimeings());
		service2.setContactNumber(service.getContactNumber());
		service2.setZip(service.getZip());
		service2.setVendor(vendor);
		serviceDao.save(service2);
		
		return "redirect:/viewServices";

	}
		
	//deletes the product
	@GetMapping("/deleteProduct")
	public String deleteProduct(@RequestParam("productId") int productId,HttpSession session) {
		
		Product product=productDao.findByProductId(productId);
		
		productDao.delete(product);	
		
		return "redirect:/viewProducts";
	}
	
	//deletes the service
	@GetMapping("/deleteService")
	public String deleteService(@RequestParam("serviceId") int serviceId,HttpSession session) {
		
		Service service=serviceDao.findByServiceId(serviceId);
		serviceDao.delete(service);
		
		return "redirect:/viewServices";
	}
	
	//delete product category
	
	
	//display edit product form
	@GetMapping("/viewEditProductCategory")
	public String viewEditProductCategory(@RequestParam("productCategoryId") int productCategoryId,HttpSession session,Model model,HttpServletRequest request) {
		ProductCategory productCategory=productCategoryDao.findAllByProductCategoryId(productCategoryId);
		model.addAttribute("productCategory",productCategory);
		session.setAttribute("productCategoryId",productCategoryId);
		request.setAttribute("mode", "MODE_VIEWEDITPRODUCTCATEGORY");
		return "vendorDetails";
		
	}
	
	//display edit service form
	@GetMapping("/viewEditServiceCategory")
	public String viewEditServiceCategory(@RequestParam("serviceCategoryId") int serviceCategoryId,HttpSession session,Model model,HttpServletRequest request) {
		ServiceCategory serviceCategory=serviceCategoryDao.findByServiceCategoryId(serviceCategoryId);
		model.addAttribute("serviceCategory",serviceCategory);
		session.setAttribute("serviceCategoryId", serviceCategoryId);
		request.setAttribute("mode", "MODE_VIEWEDITSERVICECATEGORY");
		return "vendorDetails";
		
	}
	
	
	
	//edits the product
	@PostMapping("/viewEditProductCategory/editProductCategory")
	public String editProductCategory(@ModelAttribute("productCategory") ProductCategory productCategory, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		int productCategoryId =(int) session.getAttribute("productCategoryId");
		request.setAttribute("productCategoryId", productCategoryId);
		//ProductCategory productCategory1=productCategoryDao.findByProductCategoryIdAndVendorId(productCategoryId,vendorId);
		productCategoryDao.save(productCategory);	
		productCategory.setVendor(vendor);
		productCategoryDao.save(productCategory);
		
		return "redirect:/viewProductCategorys";

	}
	
	//edits the services
	@PostMapping("/viewEditServiceCategory/editServiceCategory")
	public String editServiceCategory(@ModelAttribute("serviceCategory") ServiceCategory serviceCategory, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorDao.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		int serviceCategoryId =(int) session.getAttribute("serviceCategoryId");
		
		request.setAttribute("serviceCategoryId", serviceCategoryId);
		//ServiceCategory serviceCategory1=serviceCategoryDao.findByServiceCategoryIdAndVendorId(serviceCategoryId,vendorId);
		serviceCategoryDao.save(serviceCategory);	
		serviceCategory.setVendor(vendor);
		serviceCategoryDao.save(serviceCategory);
		
		return "redirect:/viewServiceCategorys";

	}
	
	
	
	
	
	
    //display the secret questions
	@ModelAttribute("secretQ")
	public List<String> populateQ() {
		List<String> secretQ = new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;

	}

}

package com.cognizant.model;

public class Payment {

}

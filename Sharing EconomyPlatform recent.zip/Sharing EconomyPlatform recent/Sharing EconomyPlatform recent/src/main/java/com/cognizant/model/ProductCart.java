package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class ProductCart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cartId;
	
	@OneToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH })
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@OneToMany(mappedBy = "productCart",cascade = CascadeType.ALL)
	private List<ProductCartItems> productCartItems;

	private double total;

	public ProductCart() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cartId
	 * @param customer
	 * @param productCartItems
	 * @param total
	 */
	public ProductCart(Integer cartId, Customer customer, List<ProductCartItems> productCartItems, double total) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		this.productCartItems = productCartItems;
		this.total = total;
	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<ProductCartItems> getProductCartItems() {
		return productCartItems;
	}

	public void setProductCartItems(List<ProductCartItems> productCartItems) {
		this.productCartItems = productCartItems;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	/**
	 * @param cartId
	 * @param quantity
	 * @param products
	 * @param total
	 * @param customer
	 */


}

package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class ProductCart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cartId;

	private int quantity;

	private List<Product> products = new ArrayList<>();
	
	private double total;

	@OneToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH })
	@JoinColumn(name = "customer_id")
	private Customer customer;

	public ProductCart() {
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * @param cartId
	 * @param quantity
	 * @param products
	 * @param total
	 * @param customer
	 */
	public ProductCart(Integer cartId, int quantity, List<Product> products, double total, Customer customer) {
		super();
		this.cartId = cartId;
		this.quantity = quantity;
		this.products = products;
		this.total = total;
		this.customer = customer;
	}


	
	public void addProduct(Product product) {

	}

	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public double getTotal() {
		return total;
	}


	public void setTotal(double total) {
		this.total = total;
	}


	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}

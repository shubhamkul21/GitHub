package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class ProductCartItems {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartItemId;

	private int quantity;

	private double price;

	@ManyToOne
	@JoinColumn(name = "productId")
	private Product product;

	@ManyToOne
	@JoinColumn(name = "cartId")
	private ProductCart productCart;
	
	@ManyToOne
	@JoinColumn(name = "custumer_id")
	private Customer customer;
	
	public ProductCartItems() {
		// TODO Auto-generated constructor stub

	}

	/**
	 * @param cartItemId
	 * @param quantity
	 * @param price
	 * @param product
	 * @param productCart
	 */
	public ProductCartItems(int cartItemId, int quantity, double price, Product product, ProductCart productCart) {
		super();
		this.cartItemId = cartItemId;
		this.quantity = quantity;
		this.price = price;
		this.product = product;
		this.productCart = productCart;
	}

	public int getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ProductCart getProductCart() {
		return productCart;
	}

	public void setProductCart(ProductCart productCart) {
		this.productCart = productCart;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
}

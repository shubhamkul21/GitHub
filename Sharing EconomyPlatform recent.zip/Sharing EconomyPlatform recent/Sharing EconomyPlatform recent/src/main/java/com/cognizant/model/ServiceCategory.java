package com.cognizant.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ServiceCategory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int serviceCategoryId;
	private String serviceCategoryName;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "vendor_id")
	private Vendor vendor;

	
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "serviceCategory")
	private List<Service> services;
	
	public ServiceCategory() {
		// TODO Auto-generated constructor stub
	}

	
	public ServiceCategory(int serviceCategoryId, String serviceCategoryName, Vendor vendor, List<Service> services) {
		super();
		this.serviceCategoryId = serviceCategoryId;
		this.serviceCategoryName = serviceCategoryName;
		this.vendor = vendor;
		this.services = services;
	}

	public int getServiceCategoryId() {
		return serviceCategoryId;
	}

	public void setServiceCategoryId(int serviceCategoryId) {
		this.serviceCategoryId = serviceCategoryId;
	}

	public String getServiceCategoryName() {
		return serviceCategoryName;
	}

	public void setServiceCategoryName(String serviceCategoryName) {
		this.serviceCategoryName = serviceCategoryName;
	}

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}





}

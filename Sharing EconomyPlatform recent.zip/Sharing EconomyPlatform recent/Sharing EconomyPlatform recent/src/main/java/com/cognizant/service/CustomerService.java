package com.cognizant.service;

import java.util.List;

import com.cognizant.model.Product;

public interface CustomerService {	



}

package com.cognizant.service;

import java.util.List;

import com.cognizant.model.Product;

public interface CustomerService {	


	public boolean validateSecretAns(String vendorUserId, String secretQ, String secretAns);
	
}

package com.cognizant.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CustomerDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.model.Customer;
import com.cognizant.model.Product;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private ProductDao productDao;
	
	
		public boolean validateSecretAns(String customerUserId, String secretQ, String secretAns) {
			
			// TODO Auto-generated method stub
			boolean b=false;
			Customer customer=customerDao.findByCustomerUserIdAndSecretQAndSecretAns(customerUserId,secretQ,secretAns);
			if(customer!=null)
			{
			System.out.println(customer.getContactNumber());
			b=true;
			}
			
			return b;	
			
		}
		public void resetPassword(String customerUserId, String password) {
			// TODO Auto-generated method stub
			Customer customer=customerDao.findByCustomerUserId(customerUserId);
			customer.setPassword(password);
			customerDao.save(customer);
			System.out.println(customer.getPassword());
		}
		public Customer findByCustomerUserId(String customerUserId) {
			// TODO Auto-generated method stub
			return customerDao.findByCustomerUserId( customerUserId);
			
		}

		
	
}

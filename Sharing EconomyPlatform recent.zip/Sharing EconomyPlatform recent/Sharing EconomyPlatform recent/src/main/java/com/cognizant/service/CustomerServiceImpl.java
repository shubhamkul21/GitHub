package com.cognizant.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CustomerDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.model.Product;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private ProductDao productDao;
	
//	@Override
//	public List<Product> fetchProducts(int id) {
//		//Product product=productDao.
//		//List<Product> pList=productDao.findAllById(id).get();
//
//		return null;
//	}

	
}

package com.cognizant.service;

import java.util.List;

public interface ProductCategoryService {
    List<String> getProductCategories();

	List<String> getAllProductCategories();
}

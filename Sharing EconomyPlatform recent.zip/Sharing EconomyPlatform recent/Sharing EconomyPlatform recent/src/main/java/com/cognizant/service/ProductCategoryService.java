package com.cognizant.service;

import java.util.List;

public interface ProductCategoryService {
    List<String> getProductCategories(int vid);

	List<String> getAllProductCategories();
}

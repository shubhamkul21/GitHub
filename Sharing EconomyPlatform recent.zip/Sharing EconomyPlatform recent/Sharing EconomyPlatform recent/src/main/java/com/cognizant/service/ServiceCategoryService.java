package com.cognizant.service;

import java.util.List;

public interface ServiceCategoryService {
	List<String> getServiceCategories(int vid);

	List<String> getAllServiceCategories();

}

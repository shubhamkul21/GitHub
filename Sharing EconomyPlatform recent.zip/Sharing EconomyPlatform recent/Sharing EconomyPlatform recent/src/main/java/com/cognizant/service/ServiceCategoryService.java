package com.cognizant.service;

import java.util.List;

public interface ServiceCategoryService {
	List<String> getServiceCategories();

	List<String> getAllServiceCategories();

}

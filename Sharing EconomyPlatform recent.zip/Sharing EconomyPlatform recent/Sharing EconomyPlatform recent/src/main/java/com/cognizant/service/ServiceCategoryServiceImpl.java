package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.model.ServiceCategory;
@Service
public class ServiceCategoryServiceImpl implements ServiceCategoryService{
	private ServiceCategoryDao serviceCategoryDao;
		public ServiceCategoryServiceImpl(ServiceCategoryDao serviceCategoryDao) {
		super();
		this.serviceCategoryDao = serviceCategoryDao;
	}


	@Override
	public List<String> getServiceCategories() {
		List<String> categoryName=new ArrayList<>();
		List<ServiceCategory> categories=serviceCategoryDao.findCategories();
		for(ServiceCategory category:categories) {
			categoryName.add(category.getServiceCategoryName());
		}
		
		return categoryName;
	}


	@Override
	public List<String> getAllServiceCategories() {
		List<String> categoryName=new ArrayList<>();
		List<ServiceCategory> allCategories=serviceCategoryDao.findAllCategories();
		for(ServiceCategory category:allCategories) {
			categoryName.add(category.getServiceCategoryName());
		}
		
		return categoryName;
	}
	

}

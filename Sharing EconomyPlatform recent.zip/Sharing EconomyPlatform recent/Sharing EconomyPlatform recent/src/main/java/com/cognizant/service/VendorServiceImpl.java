package com.cognizant.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.VendorDao;
import com.cognizant.model.Vendor;

@Service
@Transactional
public class VendorServiceImpl implements VendorService {
    
	@Autowired
	private VendorDao vendorDao;
	
	
	@Override
	public void update(String currentSession, String firstName, String lastName, String gender, String contactNumber,
			String address, String city, String state, String zip, String email) {
		// TODO Auto-generated method stub
		Vendor vendor=vendorDao.findByVendorUserId(currentSession);
		vendor.setFirstName(firstName);
		vendor.setLastName(lastName);
		vendor.setGender(gender);
		vendor.setContactNumber(contactNumber);
		vendor.setCity(city);
		vendor.setAddress(address);
		vendor.setState(state);
		vendor.setZip(zip);
		vendor.setEmail(email);
		vendorDao.save(vendor);
		
		}


	@Override
public boolean validateSecretAns(String vendorUserId, String secretQ, String secretAns) {
		
		// TODO Auto-generated method stub
		boolean b=false;
		Vendor vendor=vendorDao.findByVendorUserIdAndSecretQAndSecretAns(vendorUserId,secretQ,secretAns);
		if(vendor!=null)
		{
		System.out.println(vendor.getContactNumber());
		b=true;
		}
		
		return b;	
		
	}
	

	@Override
	public void resetPassword(String vendorUserId, String password) {
		// TODO Auto-generated method stub
		Vendor vendor=vendorDao.findByVendorUserId(vendorUserId);
		vendor.setPassword(password);
		vendorDao.save(vendor);
		System.out.println(vendor.getPassword());
	}
}

		
